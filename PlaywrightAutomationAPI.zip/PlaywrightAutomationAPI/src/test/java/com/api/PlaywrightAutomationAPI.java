package com.api;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.RequestOptions;
import org.json.JSONObject;
import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;


import java.util.Map;

public class PlaywrightAutomationAPI {
  public static void main(String[] args) {
	
    try (Playwright playwright = Playwright.create()) {

      // Initialize API context with base URL and headers
      APIRequestContext request = playwright.request().newContext(
        new APIRequest.NewContextOptions()
          .setBaseURL("https://reqres.in")
          .setExtraHTTPHeaders(Map.of(
            "x-api-key", "reqres-free-v1",
            "Content-Type", "application/json"
          ))
      );

      // Step 1: Create a user
      System.out.println("=== Step 1: Create a user ===");
      String createPayload = """
    		  {
    		    
    		    "email": "george.bluth@reqres.in",
    		    "password": "1234"
    		  }
    		""";


      APIResponse createResponse = request.post("/api/register",
        RequestOptions.create().setData(createPayload));

      int createStatus = createResponse.status();
      System.out.println("Create User - HTTP Status Code: " + createStatus);

      String userId = null;

      if (createStatus == 200) {
        String createBody = createResponse.text();
        System.out.println("Create User - Response Body:\n" + createBody);

        JSONObject json = new JSONObject(createBody);
        String token = json.getString("token");
        System.out.println("User created successfully. Token: " + token);

        // Since /api/register doesn't return userId, we fetch it from user list
        APIResponse listResponse = request.get("/api/users?page=1");
        JSONObject listJson = new JSONObject(listResponse.text());
        userId = String.valueOf(listJson.getJSONArray("data").getJSONObject(0).getInt("id"));
        System.out.println("Fetched User ID from list: " + userId);
      } else {
        System.out.println("User creation failed.");
        return;
      }

      // Step 2: Get the created user details and validate the same
      System.out.println("\n=== Step 2: Get the created user details and validate ===");
      APIResponse getResponse = request.get("/api/users/" + userId);
      int getStatus = getResponse.status();
      System.out.println("Get User - HTTP Status Code: " + getStatus);

      if (getStatus == 200) {
        String getBody = getResponse.text();
        System.out.println("Get User - Response Body:\n" + getBody);

        JSONObject userJson = new JSONObject(getBody).getJSONObject("data");
        System.out.println("User Name: " + userJson.getString("first_name") + " " + userJson.getString("last_name"));
        System.out.println("User Email: " + userJson.getString("email"));
      } else {
        System.out.println("Failed to fetch user details.");
        return;
      }

      // Step 3: Update user's name and validate the same
      System.out.println("\n=== Step 3: Update user's name and validate ===");
      String updatePayload = """
        {
          "name": "Sanskruti"
          
        }
      """;

      APIResponse updateResponse = request.put("/api/users/" + userId,
        RequestOptions.create().setData(updatePayload));
      int updateStatus = updateResponse.status();
      System.out.println("Update User - HTTP Status Code: " + updateStatus);

      if (updateStatus == 200) {
        String updateBody = updateResponse.text();
        System.out.println("Update User - Response Body:\n" + updateBody);

        JSONObject updateJson = new JSONObject(updateBody);
        System.out.println("User updated successfully at: " + updateJson.getString("updatedAt"));
      } else {
        System.out.println("Failed to update user.");
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}